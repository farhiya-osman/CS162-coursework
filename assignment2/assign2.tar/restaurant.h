#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <string>
#include <fstream>
#include "menu.h"
#include "emp_hours.h"

using namespace std;

class Restaurant {
  private:
    Menu menu;
    employee* employees;
    hours* week;
    order* orders; 
    string name;
    int numpizzao;
    string phone;
    string address;
    int num_employees; 
    int num_days;
    int num_orders; 
    int ordernum; 
    
  public:
  Restaurant();
  Restaurant( string name1, string phone1, string address1, int num_e, int num_d);
  Restaurant(const Restaurant& r1);
  Restaurant& operator=(const Restaurant& r1);
  //void populate_employee_data( employee* emp, ifstream& employeeinput);
  void set_employee_data(); 
  ~Restaurant(); 
  int get_num_employees()const; 
  int get_num_days()const;
  int get_num_orders()const;
  //int get_num_porders()const; 
  //pizzaname get_pizzarr(int l)const; 
  string get_name() const;
  string get_phone() const;
  string get_address() const;
  void set_name(string n);
  void set_phone(string ph);
  void set_employeesarr(employee* emp);
  void set_address(string addy);
  void set_weekarr(hours* weeks);
  void set_pizzarra(); 
  employee* get_employee(int i)const;

    //need to include accessor functions and mutator functions for each private member
    //need to include constructors, copy constructors, assignment operator overload,
    //and destructors where appropriate
    void load_data(); //reads from files to correctly populate menu, employees, hours, etc.
    bool login(); //done
    void view_menu(); //done
    void view_hours(); //done
    void view_address(); //done
    void view_phone(); //done 
    void search_menu_by_price(int cost);
    void search_by_ingredients(string ingred);
    void search_by_eingredients(string ingred);
    void set_restaurant_data(); //done
    void set_orders(); //done
    
    // Only one of the following two prototypes should be used:
    // selection is a dynamically allocated array of Pizza objects that are being ordered
    // selection_size indicates the number of Pizza objects in the array
    // num_ordered is a dynamically allocated array that indicates how many pizzas of each type were ordered
    //void place_order(Pizza* selection, int selection_size, int* num_ordered);
    // you may also choose to use this prototype:
    void place_order();
    
    void change_hours(); //done
    void add_to_menu();  //done
    void remove_from_menu(); //done
    void view_orders(); //done
    void remove_orders(); //done 
};

#endif