#ifndef EMP_HOURS_H
#define EMP_HOURS_H

#include <string>
using namespace std;

struct employee {
  int id;
  string password;
  string first_name;
  string last_name;
};

struct hours {
  string day;
  string open_hour;
  string close_hour;
};

struct order{
 int ordernum; 
 string cname; 
 string creditcard; 
 string cphone; 
 string pizzaname; 
 int quantity; 
 string size; 
 string pizzaname2; 
 int quantity2; 
 string size2;
 string pizzaname3; 
 int quantity3; 
 string size3;  
};



#endif