#include <iostream>
#include "pizza.h"
#include "menu.h"
using namespace std;


//default constructor 
/*******************************************************************
 * ** Function: Menu()
 * ** Description: default constructor  
 * ** Parameters:none  
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
Menu::Menu(){
    num_pizzas= 0; 
    pizzas = NULL;
}
//non-default constructor 
/*******************************************************************
 * ** Function: Menu(int numpiz,Pizza*P)
 * ** Description: non-default constructor  
 * ** Parameters: number of pizzas and the pizza array   
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
Menu::Menu(int numpiz, Pizza* p){
    num_pizzas = numpiz; 
    pizzas = new Pizza[num_pizzas];
    for(int i = 0; i <num_pizzas;i++){
        pizzas[i] = p[i];
    }
}
//copy constructor 
/*******************************************************************
 * ** Function: Menu(const Menu& m1)
 * ** Description: copy constructor  
 * ** Parameters:constant to copy values over
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
Menu::Menu(const Menu& m1){
    num_pizzas = m1.num_pizzas;
    pizzas = m1.pizzas;   
   // if(pizzas == 0){
    //    pizzas = NULL;
    //}
    //else{
        pizzas = new Pizza[num_pizzas];
          for(int i = 0; i<num_pizzas;i++){
          pizzas[i] = m1.pizzas[i];
    }
    //}
}
/*******************************************************************
 * ** Function:  Menu& Menu::operator= (const Menu& m1)
 * ** Description: assignment operator overload 
 * ** Parameters:constant copy 
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
//assignment operator overload 
Menu& Menu::operator= (const Menu& m1){
    num_pizzas = m1.num_pizzas;
    pizzas = m1.pizzas; 
   // if(pizzas != NULL){
     //   delete [] pizzas;
    //} 
    //if(num_pizzas == 0){
     //   pizzas = NULL;
    //}
    //else{
         pizzas = new Pizza[num_pizzas];
         for(int i = 0; i<num_pizzas;i++){
            pizzas[i] = m1.pizzas[i];
      //   }
    }

}
/*******************************************************************
 * ** Function: get_num_pizzas(), get_pizzas(l),
 * ** Description: Accessors function 
 * ** Parameters:none
 * ** Pre-conditions: none 
 * ** Post-conditions: constant
 * *******************************************************************/
int Menu::get_num_pizzas()const{
    return num_pizzas; 
}
void Menu::set_num_pizzas(int numpiz){
    num_pizzas = numpiz; 
}
Pizza Menu::get_pizzas(int l)const{
    return pizzas[l];
}
/*******************************************************************
 * ** Function: set_pizzas(),set_num_pizzas(), set_menu
 * ** Description: mutator functions 
 * ** Parameters:none
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
void Menu::set_pizzas(int num_pizzzas, Pizza* p){
    for(int i = 0; i< num_pizzas; i++){
       pizzas[i] = p[i];
    }
}
/*******************************************************************
 * ** Function:  set_menu()
 * ** Description: reads in the values from the menu text file
 * ** Parameters:none 
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
void Menu::set_menu(){
    //Pizza p; 
   // cout << "pleas enter the number of pizzas you would like in your menu" << endl; 
   // cin >> num_pizzas; 
   ifstream menuinput; 
   menuinput.open("menu.txt", ifstream::in);
      menuinput >> num_pizzas; 
      pizzas = new Pizza[num_pizzas]; 
      for(int l = 0; l<num_pizzas; l++){
         pizzas[l].populate_pizza_data(menuinput);
       } 
   menuinput.close();
}

/*******************************************************************
 * ** Function: ~Menu
 * ** Description: destructor deletes the arrays allocated in the class 
 * ** Parameters:none
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
//destructor 
Menu::~Menu(){
    delete [] pizzas;
}