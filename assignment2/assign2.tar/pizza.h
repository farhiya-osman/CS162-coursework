#ifndef PIZZA_H
#define PIZZA_H

#include <string>
#include <fstream>

using namespace std;

class Pizza {
  private:
    string name;
    int small_cost;
    int medium_cost;
    int large_cost;
    int num_ingredients;
    int p; 
    string* ingredients;
  public:
  Pizza();
  Pizza(string name1, int small, int medium, int large, int numingred, string* ingred);
  Pizza(const Pizza& p2);
  Pizza& operator= (const Pizza& p2);
  string get_name() const;
  int get_num_ingredients()const;
  int get_smallcost() const;
  int get_mediumcost() const;
  int get_largecost() const;
  string get_ingredients(int p);
  void set_name(string n);
  void set_smallcost(int small);
  void set_mediumcost(int medium);
  void set_largecost(int large);
  void set_ingredientsnum(int numingred );
  void set_ingredientsarr(string* ingred );
  void populate_pizza_data( ifstream& menuinput);
  ~Pizza();

  //how do you call assignment operator overload
    //need to include accessor functions and mutator functions for each private member
    //need to include constructors, copy constructors, assignment operator overload,
    //and destructors where appropriate
};

#endif