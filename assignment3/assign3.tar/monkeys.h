#ifndef MONKEYS_H
#define MONKEYS_H

#include <iostream>
#include "animals.h"

using namespace std;

class monkeys : public animals {
  private:

  public:
   monkeys();   

};

#endif