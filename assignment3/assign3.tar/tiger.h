#ifndef TIGER_H
#define TIGER_H

#include <string>
#include <iostream>
#include "animals.h"


using namespace std;

class tiger: public animals {
  private:

  public:
  tiger();
   //add functions for specific functions
  

};

#endif