#ifndef SLOTH_H
#define SLOTH_H

#include <string>
#include <iostream>
#include "animals.h"

using namespace std;

class sloth : public animals{
  private:
    

  public:
  sloth(); 
    //add functions for specific functions 

};

#endif