
#include <iostream>
#include "seaotter.h"


using namespace std;
/*******************************************************************
 * ** Function: seaotter
 * ** Description:  default constructor. Iniitalizes the values
 * ** Parameters:none  
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/  
seaotter::seaotter():animals(){
    age = 1; 
    numbabies = 0; 
    purchasecost = 5000.0; 
    feedingcost = 2.0; 
    sellprof = 2500.0; 
}