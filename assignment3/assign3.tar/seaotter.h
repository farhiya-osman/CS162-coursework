#ifndef SEAOTTER_H
#define SEAOTTER_H

#include <string>
#include <iostream>
#include "animals.h"


using namespace std;

class seaotter: public animals {
  private:

  public:
  seaotter();
   //add functions for specific functions
  

};

#endif