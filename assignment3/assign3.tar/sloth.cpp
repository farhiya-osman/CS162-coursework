
#include <iostream>
#include "sloth.h"



using namespace std; 
/*******************************************************************
 * ** Function: sloth
 * ** Description:  default constructor. Iniitalizes the values
 * ** Parameters:none  
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/ 
sloth::sloth():animals(){
    age = 1; 
    numbabies = 0; 
    purchasecost = 2000; 
    feedingcost = 1; 
    sellprof = 1000; 
}

