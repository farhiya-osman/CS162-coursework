
#include <iostream>
#include "tiger.h"


using namespace std; 
/*******************************************************************
 * ** Function: tiger
 * ** Description:  default constructor. Iniitalizes the values
 * ** Parameters:none  
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/ 
tiger::tiger():animals(){
    age = 1; 
    numbabies = 0; 
    purchasecost = 2400.0; 
    feedingcost = 3.0; 
    sellprof = 1200.0; 
}