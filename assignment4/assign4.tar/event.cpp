
#include "event.h"

using namespace std; 
/*******************************************************************
 * ** Function: events()
 * ** Description:    initializes the message on the board 
 * ** Parameters:none  
 * ** Pre-conditions: none 
 * ** Post-conditions: none
 * *******************************************************************/
event::event(){
    message = " "; 
}
