#include <algorithm>
#include <vector>

using namespace std;

bool containsDuplicate (vector<int>& nums){
	//Type your answer here:
}